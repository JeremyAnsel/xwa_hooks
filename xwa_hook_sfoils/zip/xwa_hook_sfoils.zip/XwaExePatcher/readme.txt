
This tool will apply the content of "patcher.xml" to "XWingAlliance.exe".

*** Requirements ***

This tool requires:
- Windows XP SP2 or superior
- .NET framework 4.0


*** Usage ***

1) Place XWA's exe ("XWingAlliance.exe") in this folder.

2) Run "XwaExePatcherWindow.exe".


*** Note ***

If "patcher.xml" or "XWingAlliance.exe" does not exist, the tool will show an open file dialog.


*** Credits ***

- J�r�my Ansel (JeremyaFr)
