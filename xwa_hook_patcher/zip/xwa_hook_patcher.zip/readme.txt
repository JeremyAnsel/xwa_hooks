xwa_hook_patcher

This hook applies patches to the xwa exe.


*** Requirements ***

This dll requires:
- Windows 7 or superior
- xwa_hook_main


*** Setup ***

Place hook_patcher.dll next to xwingalliance.exe


*** Usage ***

To define a patch add it to "hook_patcher.xml".
To enable a patch add its name to "hook_patcher.txt" with " = 1" at the end.


*** Credits ***

- J�r�my Ansel (JeremyaFr)
